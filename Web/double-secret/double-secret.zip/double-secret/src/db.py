import mysql.connector

db = mysql.connector.connect(
  host="db",
  user="root",
  password="password",
  db="chall"
)
