import UnifiedRandom from "./UnifiedRandom.js";

class Game {
	correctFirstCells;
	seed;

	constructor(seed, numberOfLevelsToWin) {
		this.ruses = 0;
		this.seed = seed;
		this.uRandom2 = new UnifiedRandom(seed);
		this.uRandomB2 = new UnifiedRandom(seed);
		this.uRandomC = new UnifiedRandom(seed);

		this.correctFirstCells = [];

		for (let i = 0; i < numberOfLevelsToWin; i++) {
			this.correctFirstCells.push(this.uRandomC.getNumber(0, 5));
		}
	}

	calculateTimes(levelIndex) {
		let repeatRate = this.uRandomB2.getNumber(8, 25) / 100;
		this.ruses++;

		let correctIndexStart = this.correctFirstCells[levelIndex];
		let correctIndexEnd = correctIndexStart + 2;

		let delay = this.uRandom2.getNumber(0, 25) / 100;
		this.ruses++;

		const graceTime = 0.1;
		let correctTimeStart = correctIndexStart * repeatRate - delay;
		let correctTimeEnd = correctIndexEnd * repeatRate - delay + graceTime;

		return [correctTimeStart, correctTimeEnd];
	}

	checkTimesCorrect(times) {
		for (let i = 0; i < times.length; i++) {
			const correctRange = this.calculateTimes(i);
			if (!(times[i] >= correctRange[0] && times[i] <= correctRange[1])) {
				return false;
			}
		}

		return true;
	}

	calculateCode(times) {
		const code =
			this.uRandomC.getNumber(0, this.uRandomC.getNumber(0, 10000)) *
			times.length *
			1.25;
		return code;
	}
}

export default Game;
