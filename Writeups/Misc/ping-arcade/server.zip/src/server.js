import express from "express";
import bodyParser from "body-parser";
import crypto from "crypto";
import Game from "./Game.js";

const port = 3000;
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const FLAG = process.env.FLAG ?? "ping{FAKE}";
const NUMBER_OF_LEVELS_TO_WIN = 64;
// 10 Minutes
const GAMES_DELETE_INTERVAL_MS = 1000 * 60 * 10;

let games = [];

// interval to delete games
setInterval(() => {
	console.log(`Deleting ${games.length} games`);
	games = [];
}, GAMES_DELETE_INTERVAL_MS);

app.get("/start-game", (req, res) => {
	const accessCode = crypto.randomBytes(20).toString("hex");

	let game = new Game(accessCode, NUMBER_OF_LEVELS_TO_WIN);
	games[accessCode] = game;

	res.json({
		success: true,
		accessCode: accessCode,
	});
});

app.post("/verify-game", (req, res) => {
	if (!req.body)
		return res.json({ success: false, flagGranted: false, flag: "" });
	if (
		!req.body["accessCode"] ||
		!req.body["controlNumber"] ||
		!req.body["times"]
	)
		return res.json({ success: false, flagGranted: false, flag: "" });
	if (
		typeof req.body["accessCode"] !== "string" ||
		typeof req.body["controlNumber"] !== "string" ||
		typeof req.body["times"] !== "string"
	) {
		return res.json({ success: false, flagGranted: false, flag: "" });
	}

	const accessCode = req.body.accessCode;
	const controlNumber = parseFloat(req.body.controlNumber);
	let times = req.body.times.replace(/,/g, ".");
	times = times.split("-");

	let isCorrect = false;

	if (times.length === NUMBER_OF_LEVELS_TO_WIN) {
		for (let time of times) {
			time = parseFloat(time);
		}

		const game = games[accessCode];
		if (!game) {
			return res.json({ success: false });
		}

		const controlNumberCorrect = game.calculateCode(times);
		if (controlNumber !== controlNumberCorrect) {
			return res.json({
				success: true,
				flagGranted: false,
				flag: "",
			});
		}

		isCorrect = game.checkTimesCorrect(times);
	}

	res.json({
		success: true,
		flagGranted: isCorrect,
		flag: isCorrect ? FLAG : "",
	});
});

app.listen(port, () => {
	console.log(`Server listening on port ${port}`);
});
